def add_numbers(x, y):
    return x + y


def divide_numbers(x, y):
    return x / y
