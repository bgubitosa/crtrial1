# Dummy Project

This is a very small dummy project used to test automated code review tools.

## What it does
- Adds two numbers
- Divides two numbers

## How to run
```bash
python app.py
```
