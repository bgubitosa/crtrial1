from utils import add_numbers, divide_numbers

def main():
    a = 10
    b = 0

    result1 = add_numbers(a, b)
    print("Addition result:", result1)

    result2 = divide_numbers(a, b)
    print("Division result:", result2)

if __name__ == "__main__":
    main()
